(function () {
'use strict';

/* ------------------------------------------------------------------
   Personajes. Para cambiar nombres o modelos, edita esta lista.
   Los archivos están en la carpeta assets/models.
------------------------------------------------------------------ */
var PERSONAJES = [
  { nombre: 'yacult2202', obj: 'models/yacult2202.obj', mtl: 'models/yacult2202.mtl' },
  { nombre: 'ronyxrob',   obj: 'models/ronyxrob.obj',   mtl: 'models/ronyxrob.mtl' }
];
var ALTO_MAX = 2.2;   // altura del modelo más alto, en unidades de la escena
var CADERA = 0.95;    // altura desde la que giran e inclinan los modelos
var SEPARACION = 1.1; // distancia de cada personaje al centro

/* ------------------------------------------------------------------
   Lectura de .obj y .mtl (los modelos se usan tal como vienen)
------------------------------------------------------------------ */
function parseMtl(txt) {
  var mats = {}, cur = null;
  txt.split('\n').forEach(function (l) {
    var p = l.trim().split(/\s+/);
    if (p[0] === 'newmtl') { cur = { kd: [1, 1, 1], map: null, overlay: false }; mats[p[1]] = cur; }
    else if (!cur) { return; }
    else if (p[0] === 'Kd') { cur.kd = [+p[1], +p[2], +p[3]]; }
    else if (p[0] === 'map_Kd') { cur.map = p[1]; }
    else if (p[0] === 'rbx_alphamode' && p[1] === 'overlay') { cur.overlay = true; }
  });
  return mats;
}

function parseObj(txt) {
  var V = [], T = [], N = [], grupos = {}, mat = 'default';
  var lines = txt.split('\n');
  for (var li = 0; li < lines.length; li++) {
    var l = lines[li];
    if (l.length < 2) continue;
    if (l.charAt(0) === 'v' && l.charAt(1) === ' ') {
      var p = l.trim().split(/\s+/); V.push(+p[1], +p[2], +p[3]);
    } else if (l.charAt(0) === 'v' && l.charAt(1) === 't') {
      var q = l.trim().split(/\s+/); T.push(+q[1], +q[2]);
    } else if (l.charAt(0) === 'v' && l.charAt(1) === 'n') {
      var r = l.trim().split(/\s+/); N.push(+r[1], +r[2], +r[3]);
    } else if (l.indexOf('usemtl') === 0) {
      mat = l.trim().split(/\s+/)[1];
    } else if (l.charAt(0) === 'f' && l.charAt(1) === ' ') {
      var f = l.trim().split(/\s+/);
      var g = grupos[mat] || (grupos[mat] = { pos: [], uv: [], nor: [] });
      for (var k = 1; k + 2 < f.length; k++) {
        var tri = [1, k + 1, k + 2];
        for (var t = 0; t < 3; t++) {
          var c = f[tri[t]].split('/');
          var vi = (+c[0] - 1) * 3;
          g.pos.push(V[vi], V[vi + 1], V[vi + 2]);
          if (c[1]) { var ti = (+c[1] - 1) * 2; g.uv.push(T[ti], T[ti + 1]); } else { g.uv.push(0, 0); }
          if (c[2]) { var ni = (+c[2] - 1) * 3; g.nor.push(N[ni], N[ni + 1], N[ni + 2]); } else { g.nor.push(0, 1, 0); }
        }
      }
    }
  }
  return grupos;
}

window.__bailarines = { parseMtl: parseMtl, parseObj: parseObj };
if (!window.THREE) {
  if (typeof document !== 'undefined' && document.getElementById('msg')) {
    document.getElementById('msg').textContent = 'No se encontró three.min.js en la carpeta assets.';
  }
  return;
}

/* ------------------------------------------------------------------
   Escena
------------------------------------------------------------------ */
var $ = function (id) { return document.getElementById(id); };
var canvas = $('gl'), msg = $('msg');
var renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.setClearColor(0x151823, 1);
var scene = new THREE.Scene();
var camera = new THREE.PerspectiveCamera(38, 1, 0.1, 60);
scene.add(new THREE.HemisphereLight(0xffffff, 0x8a93aa, 1.05));
var sol = new THREE.DirectionalLight(0xffffff, 0.55); sol.position.set(2, 5, 4); scene.add(sol);

var suelo = new THREE.Mesh(new THREE.CircleGeometry(3.6, 64), new THREE.MeshBasicMaterial({ color: 0x1d2230 }));
suelo.rotation.x = -Math.PI / 2; suelo.position.y = -0.005; scene.add(suelo);

function textura_sombra() {
  var c = document.createElement('canvas'); c.width = c.height = 128; var g = c.getContext('2d');
  var gr = g.createRadialGradient(64, 64, 4, 64, 64, 64);
  gr.addColorStop(0, 'rgba(0,0,0,.6)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}
var texSombra = textura_sombra();

var theta = 0, dragging = false, lastX = 0, dist = 8;
function ajustar() {
  var w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w / h; camera.updateProjectionMatrix();
  var tanv = Math.tan(camera.fov * Math.PI / 360);
  dist = Math.max(6.2, 4.6 / (2 * tanv * camera.aspect));
}
window.addEventListener('resize', ajustar); ajustar();
canvas.addEventListener('pointerdown', function (e) { dragging = true; lastX = e.clientX; try { canvas.setPointerCapture(e.pointerId); } catch (x) {} });
canvas.addEventListener('pointermove', function (e) {
  if (!dragging) return;
  theta -= (e.clientX - lastX) * 0.008; theta = Math.max(-1.2, Math.min(1.2, theta)); lastX = e.clientX;
});
['pointerup', 'pointercancel'].forEach(function (ev) { canvas.addEventListener(ev, function () { dragging = false; }); });

/* ------------------------------------------------------------------
   Materiales y texturas
------------------------------------------------------------------ */
function texto(u) { return fetch(u).then(function (r) { if (!r.ok) throw new Error('No se pudo leer ' + u); return r.text(); }); }
function cargarImagen(u) {
  return new Promise(function (ok, err) {
    var i = new Image(); i.onload = function () { ok(i); }; i.onerror = function () { err(new Error('No se pudo cargar ' + u)); }; i.src = u;
  });
}
function tieneAlfa(img) {
  if (img.width > 512 || img.height > 512) return false;
  var c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
  var g = c.getContext('2d'); g.drawImage(img, 0, 0);
  var d = g.getImageData(0, 0, c.width, c.height).data;
  for (var i = 3; i < d.length; i += 4) if (d[i] < 250) return true;
  return false;
}
function crearMaterial(info, dir, repetir) {
  var opts = { side: THREE.DoubleSide };
  if (!info) return Promise.resolve(new THREE.MeshLambertMaterial(opts));
  if (!info.map) {
    opts.color = new THREE.Color(info.kd[0], info.kd[1], info.kd[2]);
    return Promise.resolve(new THREE.MeshLambertMaterial(opts));
  }
  return cargarImagen(dir + info.map).then(function (img) {
    var tex;
    if (info.overlay) {
      // "overlay": la textura se pone encima del color base del material
      var c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
      var g = c.getContext('2d');
      g.fillStyle = 'rgb(' + info.kd.map(function (v) { return Math.round(v * 255); }).join(',') + ')';
      g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0);
      tex = new THREE.CanvasTexture(c);
    } else {
      tex = new THREE.Texture(img); tex.needsUpdate = true;
      if (tieneAlfa(img)) { opts.transparent = true; opts.alphaTest = 0.01; }
    }
    tex.encoding = THREE.sRGBEncoding; tex.anisotropy = 4;
    if (repetir) { tex.wrapS = tex.wrapT = THREE.RepeatWrapping; } // coordenadas fuera de 0 a 1
    if (img.width <= 8) tex.magFilter = THREE.NearestFilter;
    opts.map = tex;
    return new THREE.MeshLambertMaterial(opts);
  });
}

/* ------------------------------------------------------------------
   Carga de personajes
------------------------------------------------------------------ */
var chars = [];
function cargarTodo() {
  return Promise.all(PERSONAJES.map(function (cfg) {
    return Promise.all([texto(cfg.obj), texto(cfg.mtl)]).then(function (r) {
      return { cfg: cfg, grupos: parseObj(r[0]), mtl: parseMtl(r[1]) };
    });
  })).then(function (datos) {
    datos.forEach(function (d) {
      var mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
      for (var m in d.grupos) {
        var p = d.grupos[m].pos;
        for (var i = 0; i < p.length; i += 3) for (var k = 0; k < 3; k++) { var v = p[i + k]; if (v < mn[k]) mn[k] = v; if (v > mx[k]) mx[k] = v; }
      }
      d.mn = mn; d.mx = mx;
    });
    var maxH = Math.max.apply(null, datos.map(function (d) { return d.mx[1] - d.mn[1]; }));
    var esc = ALTO_MAX / maxH;
    var seq = Promise.resolve();
    datos.forEach(function (d, idx) {
      seq = seq.then(function () { return construir(d, idx, esc, datos.length); });
    });
    return seq;
  });
}

function construir(d, idx, esc, total) {
  var slotX = (idx - (total - 1) / 2) * 2 * SEPARACION;
  var slot = new THREE.Group(); slot.position.x = slotX; scene.add(slot);
  var sombra = new THREE.Mesh(new THREE.CircleGeometry(0.95, 40), new THREE.MeshBasicMaterial({ map: texSombra, transparent: true, depthWrite: false }));
  sombra.rotation.x = -Math.PI / 2; sombra.position.y = 0.002; slot.add(sombra);
  var pivot = new THREE.Group(); slot.add(pivot);
  var body = new THREE.Group(); body.position.y = -CADERA; body.rotation.y = Math.PI; pivot.add(body); // de frente a la cámara
  var cx = (d.mn[0] + d.mx[0]) / 2, cz = (d.mn[2] + d.mx[2]) / 2;
  var geos = [];
  var nombres = Object.keys(d.grupos);
  var seq = Promise.resolve();
  nombres.forEach(function (nm) {
    seq = seq.then(function () {
      var g = d.grupos[nm], n = g.pos.length, pos = new Float32Array(n);
      for (var k = 0; k < n; k += 3) {
        pos[k] = (g.pos[k] - cx) * esc; pos[k + 1] = (g.pos[k + 1] - d.mn[1]) * esc; pos[k + 2] = (g.pos[k + 2] - cz) * esc;
      }
      var geo = new THREE.BufferGeometry();
      var attr = new THREE.BufferAttribute(pos.slice(), 3); attr.setUsage(THREE.DynamicDrawUsage);
      geo.setAttribute('position', attr);
      geo.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(g.nor), 3));
      geo.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(g.uv), 2));
      var uvMin = 1e9, uvMax = -1e9;
      for (var q = 0; q < g.uv.length; q++) { var uq = g.uv[q]; if (uq < uvMin) uvMin = uq; if (uq > uvMax) uvMax = uq; }
      var repetir = uvMin < -0.05 || uvMax > 1.05;
      return crearMaterial(d.mtl[nm], 'models/', repetir).then(function (mat) {
        var mesh = new THREE.Mesh(geo, mat); mesh.frustumCulled = false; body.add(mesh);
        geos.push({ attr: attr, base: pos });
      });
    });
  });
  return seq.then(function () {
    chars.push({ cfg: d.cfg, slotX: slotX, pivot: pivot, geos: geos, deformado: false, etiqueta: $('n' + idx) });
    if ($('n' + idx)) $('n' + idx).textContent = d.cfg.nombre;
  });
}

/* ------------------------------------------------------------------
   Bailes sin huesos: se mueve el cuerpo completo (salto, inclinación,
   giro, estirar y aplastar) y se curva la malla según la altura.
------------------------------------------------------------------ */
var PI = Math.PI, TAU = Math.PI * 2;
function clamp01(x) { return Math.min(1, Math.max(0, x)); }
function suave(x) { return x * x * (3 - 2 * x); }
function neutro() { return { x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0, sy: 1, sxz: 1, ola: 0, fase: 0, tor: 0 }; }

var BAILES = [
  { nombre: 'Saltito', f: function (b, o) {
    var s = Math.abs(Math.sin(PI * b));
    o.y = 0.30 * s; o.sy = 0.90 + 0.16 * s; o.sxz = 1 / Math.sqrt(o.sy); o.rz = 0.07 * Math.sin(PI * b);
  } },
  { nombre: 'Balanceo', f: function (b, o) {
    o.rz = 0.22 * Math.sin(PI * b); o.x = 0.18 * Math.sin(PI * b); o.ry = 0.25 * Math.sin(PI * b * 0.5);
    o.y = 0.04 * Math.abs(Math.cos(PI * b));
  } },
  { nombre: 'Giro', f: function (b, o) {
    var f = b / 4, k = Math.floor(f), r = f - k, q = clamp01(r * 2);
    o.ry = TAU * (k + suave(q)); o.y = 0.22 * Math.sin(PI * q);
  } },
  { nombre: 'Pulso', f: function (b, o) {
    var g = Math.pow(Math.max(0, Math.cos(TAU * b)), 6);
    o.sy = 1 + 0.14 * g; o.sxz = 1 - 0.05 * g; o.rx = 0.12 * Math.sin(TAU * b); o.ry = 0.15 * Math.sin(PI * b); o.y = 0.06 * g;
  } },
  { nombre: 'Ola', f: function (b, o) {
    o.ola = 0.22; o.fase = PI * b; o.rz = 0.05 * Math.sin(PI * b); o.y = 0.03 * Math.abs(Math.sin(PI * b));
  } },
  { nombre: 'Torsión', f: function (b, o) {
    o.tor = Math.sin(PI * b * 0.5); o.ry = 0.2 * Math.sin(PI * b * 0.5); o.y = 0.05 * Math.abs(Math.sin(PI * b));
  } }
];
BAILES.push({ nombre: 'Mezcla', f: function (b, o) { BAILES[Math.floor(b / 8) % 6].f(b, o); } });

function deformar(ch, o) {
  var activo = o.ola !== 0 || o.tor !== 0;
  if (!activo && !ch.deformado) return;
  for (var gi = 0; gi < ch.geos.length; gi++) {
    var g = ch.geos[gi], pos = g.attr.array, bs = g.base;
    for (var i = 0; i < pos.length; i += 3) {
      var x = bs[i], y = bs[i + 1], z = bs[i + 2];
      if (!activo) { pos[i] = x; pos[i + 1] = y; pos[i + 2] = z; continue; }
      var h = Math.min(1, y / ALTO_MAX), h2 = h * h, a = o.tor * h2, c = Math.cos(a), s = Math.sin(a);
      pos[i] = x * c - z * s + Math.sin(o.fase + h * 4) * o.ola * h2;
      pos[i + 1] = y;
      pos[i + 2] = x * s + z * c + Math.cos(o.fase * 0.5 + h * 3) * o.ola * 0.5 * h2;
    }
    g.attr.needsUpdate = true;
  }
  ch.deformado = activo;
}

/* ------------------------------------------------------------------
   Ritmo y música sintetizada
------------------------------------------------------------------ */
var bpm = 110, fase0 = 0, tRef = performance.now();
function fase(now) { return fase0 + (now - tRef) * bpm / 60000; }
var ctx = null, musica = false, siguientePaso = 0;
function cambiarBpm(v) {
  var now = performance.now(); fase0 = fase(now); tRef = now; bpm = v; siguientePaso = Math.ceil(fase0 * 4);
}
function kick(t) {
  var o = ctx.createOscillator(), g = ctx.createGain();
  o.frequency.setValueAtTime(160, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.12);
  g.gain.setValueAtTime(0.9, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
  o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + 0.28);
}
var ruido = null;
function hat(t) {
  if (!ruido) {
    ruido = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.06), ctx.sampleRate);
    var d = ruido.getChannelData(0); for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  var s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
  s.buffer = ruido; f.type = 'highpass'; f.frequency.value = 7000;
  g.gain.setValueAtTime(0.22, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
  s.connect(f); f.connect(g); g.connect(ctx.destination); s.start(t);
}
var NOTAS = [110, 110, 130.8, 98];
function bajo(t, freq) {
  var o = ctx.createOscillator(), g = ctx.createGain();
  o.type = 'triangle'; o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.28, t + 0.02); g.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
  o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + 0.25);
}
function sonar(paso, t) {
  var s = paso % 16;
  if (s % 4 === 0) kick(t);
  if (s % 4 === 2) hat(t);
  if (s === 0 || s === 3 || s === 6 || s === 10 || s === 12) bajo(t, NOTAS[Math.floor(paso / 16) % NOTAS.length]);
}
function programar() {
  if (!ctx || !musica) return;
  var now = performance.now();
  for (var guard = 0; guard < 64; guard++) {
    var ts = tRef + (siguientePaso / 4 - fase0) * 60000 / bpm;
    if (ts > now + 150) break;
    if (ts >= now - 40) sonar(siguientePaso, ctx.currentTime + Math.max(0, (ts - now) / 1000));
    siguientePaso++;
  }
}
setInterval(programar, 25);

/* ------------------------------------------------------------------
   Controles
------------------------------------------------------------------ */
var actual = 0, alternados = false;
var cont = $('bailes');
BAILES.forEach(function (b, i) {
  var bt = document.createElement('button'); bt.type = 'button'; bt.textContent = b.nombre;
  bt.setAttribute('aria-pressed', i === 0 ? 'true' : 'false');
  bt.addEventListener('click', function () {
    actual = i; Array.prototype.forEach.call(cont.children, function (c, k) { c.setAttribute('aria-pressed', k === i ? 'true' : 'false'); });
  });
  cont.appendChild(bt);
});
$('bpm').addEventListener('input', function (e) { var v = +e.target.value; $('bpmv').textContent = v + ' bpm'; cambiarBpm(v); });
$('modo').addEventListener('click', function (e) {
  alternados = !alternados; e.target.setAttribute('aria-pressed', String(alternados)); e.target.textContent = alternados ? 'Alternados' : 'Juntos';
});
$('modo').textContent = 'Juntos';
$('musica').addEventListener('click', function (e) {
  musica = !musica; e.target.setAttribute('aria-pressed', String(musica));
  if (musica) {
    try {
      if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
      ctx.resume(); siguientePaso = Math.ceil(fase(performance.now()) * 4);
    } catch (err) { musica = false; e.target.setAttribute('aria-pressed', 'false'); }
  }
});

/* ------------------------------------------------------------------
   Animación
------------------------------------------------------------------ */
var v3 = new THREE.Vector3();
function animar(now) {
  requestAnimationFrame(animar);
  var b = fase(now);
  chars.forEach(function (ch, i) {
    var o = neutro(), bb = b + (alternados && i % 2 === 1 ? 0.5 : 0);
    BAILES[actual].f(bb, o);
    ch.pivot.position.set(o.x, CADERA * o.sy + o.y, o.z);
    ch.pivot.rotation.set(o.rx, o.ry, o.rz, 'YXZ');
    ch.pivot.scale.set(o.sxz, o.sy, o.sxz);
    deformar(ch, o);
  });
  camera.position.set(dist * Math.sin(theta), 1.55, dist * Math.cos(theta));
  camera.lookAt(0, 0.75, 0);
  renderer.render(scene, camera);
  var w = window.innerWidth, h = window.innerHeight;
  chars.forEach(function (ch) {
    if (!ch.etiqueta) return;
    v3.set(ch.slotX, 0, 0.4).project(camera);
    ch.etiqueta.style.left = ((v3.x * 0.5 + 0.5) * w) + 'px';
    ch.etiqueta.style.top = ((-v3.y * 0.5 + 0.5) * h + 6) + 'px';
  });
}

cargarTodo().then(function () {
  msg.style.display = 'none';
  requestAnimationFrame(animar);
}).catch(function (e) {
  msg.textContent = 'Error: ' + e.message;
});

})();
