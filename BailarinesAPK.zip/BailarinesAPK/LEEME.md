# Bailarines

App Android (8.0 o superior) que muestra dos personajes 3D bailando, usando los
modelos .obj incluidos en `app/src/main/assets/models`. No usa huesos: cada baile
mueve el cuerpo completo (saltos, inclinaciones, giros, estirar y aplastar) y,
en "Ola" y "Torsión", curva la malla según la altura.

Controles: elegir baile, ritmo (70 a 170 bpm), música sintetizada (botón Música),
bailar juntos o alternados, y arrastrar con el dedo para girar la cámara.

## Compilar el APK en GitHub

El archivo `three.min.js` (librería 3D) se descarga solo durante la compilación.
Pasos y código del workflow: ver el mensaje donde recibiste este zip.

## Cambiar nombres o modelos

Edita la lista `PERSONAJES` al inicio de `app/src/main/assets/app.js`.
Cada modelo necesita su .obj, su .mtl y las texturas .png que nombra el .mtl,
todo dentro de `app/src/main/assets/models`.

## Agregar o ajustar bailes

En `app.js`, lista `BAILES`. Cada baile recibe el tiempo en pulsos (`b`) y llena
valores de posición, rotación y escala del cuerpo.
